"""Isolated tests for the five controller methods; no display is required."""
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pygame
import pytest

from game import BUTTON, Game
from model import GameState


@pytest.fixture
def controller():
    app = object.__new__(Game)
    app.window = SimpleNamespace(get_size=lambda: (1200, 800))
    app.state = GameState(seed=42)
    app.sound = Mock()
    app.draw = Mock()
    app.running = True
    app.team_menu = False
    return app


def test_viewport_at_native_resolution(controller):
    assert controller.viewport() == ((1200, 800), (0, 0))


def test_mouse_coordinates_at_native_resolution(controller):
    assert controller.logical_mouse((300, 400)) == (300, 400)


def test_space_starts_one_throw(controller):
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_SPACE))
    assert controller.state.throws == 1
    controller.sound.play.assert_called_once_with('throw')


@pytest.mark.parametrize('key, expected', [(pygame.K_1, 0), (pygame.K_2, 1), (pygame.K_3, 2)])
def test_number_keys_select_items(controller, key, expected):
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=key))
    assert controller.state.selected == expected


@pytest.mark.parametrize('event', [
    pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE),
    pygame.event.Event(pygame.QUIT),
])
def test_exit_events_stop_loop(controller, event):
    controller.handle_event(event)
    assert controller.running is False


def test_reset_event_clears_progress(controller):
    controller.state.throw()
    controller.state.update(0.8)
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_r))
    assert controller.state.throws == controller.state.hits == 0
    assert not controller.state.projectiles
    assert not controller.state.particles


def test_left_click_on_button_throws(controller):
    controller.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=BUTTON.center))
    assert controller.state.throws == 1


def test_mute_event_calls_sound_toggle(controller):
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_m))
    controller.sound.toggle.assert_called_once_with()


def test_step_updates_and_renders_after_impact(controller):
    controller.state = Mock()
    controller.state.update.return_value = 1
    with patch('pygame.event.get', return_value=[]):
        controller.step(0.1)
    controller.state.update.assert_called_once_with(0.1)
    controller.sound.play.assert_called_once_with('hit')
    controller.draw.assert_called_once_with()
