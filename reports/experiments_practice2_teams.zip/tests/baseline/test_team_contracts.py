from unittest.mock import Mock, patch
from game import Game
from model import GameState

def test_model_swap_opponent():
    state = GameState()
    state.choose_club('target', 0)
    assert (state.throwers, state.target) == (1, 0)

def test_game_menu_pauses_simulation():
    app = object.__new__(Game)
    app.team_menu = True
    app.state = Mock()
    app.sound = Mock()
    app.draw = Mock()
    with patch('pygame.event.get', return_value=[]):
        app.step(0.1)
    app.state.update.assert_not_called()
    app.sound.play.assert_not_called()
    app.draw.assert_called_once()
