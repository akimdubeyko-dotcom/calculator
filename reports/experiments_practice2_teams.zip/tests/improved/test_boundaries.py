"""Additional checks motivated by surviving mutants, plus boundary cases."""
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pygame
import pytest

from game import BUTTON, ITEM_RECTS, Game
from model import GameState, Particle, Projectile


@pytest.fixture
def controller():
    app = object.__new__(Game)
    app.window = SimpleNamespace(get_size=lambda: (1600, 800))
    app.state = GameState(seed=42)
    app.sound = Mock()
    app.draw = Mock()
    app.running = True
    app.team_menu = False
    return app


def test_arc_height_at_midpoint_matches_specification():
    projectile = Projectile((100, 400), (600, 500), 0)
    projectile.age = 0.4
    assert projectile.position == pytest.approx((350, 305))


def test_progress_clamps_negative_age_to_start():
    projectile = Projectile((100, 400), (600, 500), 0, age=-0.2)
    assert projectile.progress == 0
    assert projectile.position == projectile.start


@pytest.mark.parametrize('kind', [-1, 3, 100])
def test_invalid_item_index_does_not_change_selection(kind):
    state = GameState(seed=42)
    state.select(2)
    state.select(kind)
    assert state.selected == 2


def test_throw_is_blocked_one_millisecond_before_cooldown_ends():
    state = GameState(seed=42)
    assert state.throw()
    state.update(0.249)
    assert state.throw() is False
    assert state.throws == 1
    state.update(0.001)
    assert state.throw() is True


def test_particle_velocity_changes_under_gravity():
    state = GameState(seed=42)
    state.particles = [Particle(10, 20, 30, -40, 1.0, (255, 255, 255))]
    state.update(0.1)
    particle = state.particles[0]
    assert (particle.x, particle.y, particle.vx, particle.vy, particle.life) == pytest.approx((13, 16, 30, 6, 0.9))


def test_particle_is_removed_at_exact_zero_lifetime():
    state = GameState(seed=42)
    state.particles = [Particle(10, 20, 0, 0, 0.5, (255, 255, 255))]
    state.update(0.5)
    assert state.particles == []


@pytest.mark.parametrize('size, expected', [
    ((1600, 800), ((1200, 800), (200, 0))),
    ((1200, 1000), ((1200, 800), (0, 100))),
    ((600, 400), ((600, 400), (0, 0))),
])
def test_viewport_preserves_aspect_ratio_and_centres_image(controller, size, expected):
    controller.window.get_size = lambda: size
    assert controller.viewport() == expected


def test_mouse_mapping_subtracts_letterbox_offset(controller):
    assert controller.logical_mouse((800, 400)) == pytest.approx((600, 400))


def test_mouse_mapping_in_half_size_window(controller):
    controller.window.get_size = lambda: (600, 400)
    assert controller.logical_mouse((150, 200)) == pytest.approx((300, 400))


def test_rejected_throw_does_not_play_another_sound(controller):
    controller.throw()
    controller.throw()
    assert controller.state.throws == 1
    controller.sound.play.assert_called_once_with('throw')


def test_step_without_impact_does_not_play_hit_sound(controller):
    controller.state = Mock()
    controller.state.update.return_value = 0
    with patch('pygame.event.get', return_value=[]):
        controller.step(0.1)
    controller.state.update.assert_called_once_with(0.1)
    controller.sound.play.assert_not_called()
    controller.draw.assert_called_once_with()


def test_step_dispatches_events_before_updating(controller):
    controller.handle_event = Mock()
    event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_3)
    with patch('pygame.event.get', return_value=[event]):
        controller.step(0)
    controller.handle_event.assert_called_once_with(event)


def test_right_mouse_button_does_not_throw(controller):
    controller.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=3, pos=(BUTTON.centerx+200, BUTTON.centery)))
    assert controller.state.throws == 0


@pytest.mark.parametrize('index', [0, 1, 2])
def test_item_cards_are_clickable_after_window_resizing(controller, index):
    rect = ITEM_RECTS[index]
    controller.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=(rect.centerx+200, rect.centery)))
    assert controller.state.selected == index


def test_resize_enforces_minimum_window_dimensions(controller):
    window = object()
    with patch('pygame.display.set_mode', return_value=window) as set_mode:
        controller.handle_event(pygame.event.Event(pygame.VIDEORESIZE, w=50, h=20))
    set_mode.assert_called_once_with((480, 320), pygame.RESIZABLE)
    assert controller.window is window


def test_unrecognised_key_leaves_state_unchanged(controller):
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_a))
    assert controller.state.selected == 0
    assert controller.state.throws == 0
    assert controller.running is True
