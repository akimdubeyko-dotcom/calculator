"""Reproduce the coursework experiments without modifying the playable game.

All variants live in fresh temporary directories. A killed mutant must cause an
actual test failure: collection errors, empty suites and timeouts are separate.
The 28 rules below define a bounded educational sample, not all possible mutants.
"""
import ast
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


@dataclass(frozen=True)
class Mutation:
    id: str
    module: str
    method: str
    operator: str
    before: str
    after: str
    description: str


MUTATIONS = [
    Mutation('M01', 'model.py', 'Projectile.position', 'AOR', '- 145 * 4', '+ 145 * 4', 'Дуга направлена вниз'),
    Mutation('M02', 'model.py', 'Projectile.position', 'CRP', '145 * 4', '120 * 4', 'Высота дуги уменьшена'),
    Mutation('M03', 'model.py', 'Projectile.progress', 'SDL', 'min(1.0, max(0.0, self.age / self.duration))', 'max(0.0, self.age / self.duration)', 'Снят верхний предел прогресса'),
    Mutation('M04', 'model.py', 'Projectile.progress', 'SDL', 'min(1.0, max(0.0, self.age / self.duration))', 'min(1.0, self.age / self.duration)', 'Снят нижний предел прогресса'),
    Mutation('M05', 'model.py', 'GameState.select', 'ROR', 'if kind in range(len(ITEMS)):', 'if kind <= len(ITEMS):', 'Принят недопустимый индекс предмета'),
    Mutation('M06', 'model.py', 'GameState.throw', 'ROR', 'if self.cooldown > 1e-9:', 'if self.cooldown < 1e-9:', 'Инвертирован запрет броска'),
    Mutation('M07', 'model.py', 'GameState.throw', 'CRP', 'if self.cooldown > 1e-9:', 'if self.cooldown > 0.1:', 'Бросок разрешён до конца задержки'),
    Mutation('M08', 'model.py', 'GameState.throw', 'AOR', 'self.throws % len(FANS)', 'self.throws % (len(FANS) - 1)', 'Последний фанат пропущен'),
    Mutation('M09', 'model.py', 'GameState.throw', 'CRP', 'self.throws += 1', 'self.throws += 2', 'Броски считаются дважды'),
    Mutation('M10', 'model.py', 'GameState.update', 'ROR', 'if projectile.progress < 1:', 'if projectile.progress <= 1:', 'Попадание не фиксируется на границе полёта'),
    Mutation('M11', 'model.py', 'GameState.update', 'CRP', 'self.hits += 1', 'self.hits += 0', 'Попадание не увеличивает счётчик'),
    Mutation('M12', 'model.py', 'GameState.update', 'LOR', 'not math.isfinite(dt) or dt < 0', 'not math.isfinite(dt) and dt < 0', 'Ослаблена проверка времени'),
    Mutation('M13', 'model.py', 'GameState.update', 'ROR', 'or dt < 0:', 'or dt <= 0:', 'Нулевой шаг ошибочно запрещён'),
    Mutation('M14', 'model.py', 'GameState.update', 'CRP', 'particle.vy += 460 * dt', 'particle.vy += 0 * dt', 'Отключено ускорение частиц'),
    Mutation('M15', 'model.py', 'GameState.update', 'ROR', 'if p.life > 0]', 'if p.life >= 0]', 'Частица сохраняется при нулевом времени жизни'),
    Mutation('M16', 'model.py', 'Projectile.position', 'AOR', 'self.start[0] + (self.end[0] - self.start[0]) * t', 'self.start[0] - (self.end[0] - self.start[0]) * t', 'Горизонтальный полёт в обратную сторону'),
    Mutation('G01', 'game.py', 'Game.viewport', 'CRP', 'scale = min(width/WIDTH, height/HEIGHT)', 'scale = max(width/WIDTH, height/HEIGHT)', 'Изображение не помещается в окно'),
    Mutation('G02', 'game.py', 'Game.viewport', 'CRP', '(width-size[0])//2', '(width-size[0])//3', 'Неверное центрирование по горизонтали'),
    Mutation('G03', 'game.py', 'Game.logical_mouse', 'AOR', '(position[0]-offset[0])*WIDTH', '(position[0]+offset[0])*WIDTH', 'Смещение мыши прибавляется'),
    Mutation('G04', 'game.py', 'Game.handle_event', 'ROR', 'event.button == 1:', 'event.button != 1:', 'Обрабатывается другая кнопка мыши'),
    Mutation('G05', 'game.py', 'Game.handle_event', 'SDL', 'elif event.key == pygame.K_SPACE:\n                self.throw()', 'elif event.key == pygame.K_SPACE:\n                pass', 'Пробел не запускает бросок'),
    Mutation('G06', 'game.py', 'Game.handle_event', 'AOR', 'self.state.select(event.key-pygame.K_1)', 'self.state.select(event.key-pygame.K_1+1)', 'Номера предметов смещены'),
    Mutation('G07', 'game.py', 'Game.throw', 'LOR', 'if self.state.throw():', 'if self.state.throw() or True:', 'Звук звучит при отклонённом броске'),
    Mutation('G08', 'game.py', 'Game.step', 'ROR', 'if not self.team_menu and self.state.update(dt):', 'if not self.team_menu and self.state.update(dt) >= 0:', 'Звук попадания звучит без попадания'),
]

MUTATIONS += [
    Mutation('M17', 'model.py', 'GameState.choose_club', 'SDL', 'setattr(self, other, getattr(self, role))', 'pass', 'Не меняется сторона соперника'),
    Mutation('M18', 'model.py', 'GameState.choose_club', 'SDL', '        self.reset()\n        return True', '        return True', 'Смена клуба не очищает раунд'),
    Mutation('G09', 'game.py', 'Game.step', 'SDL', 'if not self.team_menu and self.state.update(dt):', 'if self.state.update(dt):', 'Симуляция продолжается в меню'),
    Mutation('G10', 'game.py', 'Game.handle_event', 'CRP', 'if TEAM_BUTTON.collidepoint(pos):', 'if False:', 'Кнопка выбора команд не открывает меню'),
]
BUGS = [Mutation('BUG-MODEL-02', 'model.py', 'GameState.choose_club', 'SDL', 'setattr(self, other, getattr(self, role))', 'pass', 'При выборе соперника обе стороны получают один клуб'),
        Mutation('BUG-GAME-02', 'game.py', 'Game.step', 'SDL', 'if not self.team_menu and self.state.update(dt):', 'if self.state.update(dt):', 'Открытое меню не приостанавливает игру')]



def modified(source, mutation):
    if source.count(mutation.before) != 1:
        raise ValueError(f'{mutation.id}: expected exactly one matching source fragment')
    result = source.replace(mutation.before, mutation.after, 1)
    ast.parse(result)
    return result


def junit_counts(path):
    if not path.exists():
        return {'tests': 0, 'failures': 0, 'errors': 1, 'skipped': 0}
    node = ET.parse(path).getroot()
    suites = [node] if node.tag == 'testsuite' else list(node.iter('testsuite'))
    # pytest 9 adds unittest subtest reports to the suite's `tests` attribute,
    # but keeps one testcase element per collected test. Preserve both counts.
    return {'tests': len(list(node.iter('testcase'))),
            'junit_reported_tests': sum(int(s.get('tests', 0)) for s in suites),
            **{key: sum(int(s.get(key, 0)) for s in suites) for key in ('failures', 'errors', 'skipped')}}


def run_suite(label, suite, mutation=None, coverage=False, smoke=False):
    out = RESULTS / label
    out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='derby-pr2-') as name:
        work = Path(name)
        for module in ('model.py', 'game.py'):
            source = (ROOT / 'src' / module).read_text()
            if mutation and mutation.module == module:
                source = modified(source, mutation)
                (out / module).write_text(source)
                (out / 'mutation.json').write_text(json.dumps(asdict(mutation), ensure_ascii=False, indent=2))
            (work / module).write_text(source)
        shutil.copytree(ROOT / 'tests' / suite, work / 'tests')
        env = dict(os.environ)
        env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONDONTWRITEBYTECODE='1',
                   PYGAME_HIDE_SUPPORT_PROMPT='1', SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy')
        command = [sys.executable, '-m']
        if coverage:
            command += ['coverage', 'run', '--branch', '--source=model,game', '-m']
        command += ['pytest', '-q', '--tb=short', '--junitxml=' + str(out / 'junit.xml')]
        try:
            process = subprocess.run(command, cwd=work, env=env, text=True, capture_output=True, timeout=40)
        except subprocess.TimeoutExpired as error:
            (out / 'pytest.log').write_text(str(error))
            return {'status': 'timeout', 'exit_code': None, 'tests': 0}
        (out / 'pytest.log').write_text(process.stdout + process.stderr)
        counts = junit_counts(out / 'junit.xml')
        if process.returncode == 0 and counts['tests'] > 0 and not counts['errors'] and not counts['failures']:
            status = 'survived' if mutation else 'passed'
        elif process.returncode == 1 and counts['failures'] > 0 and counts['errors'] == 0:
            status = 'killed' if mutation else 'failed'
        else:
            status = 'error'
        record = {'status': status, 'exit_code': process.returncode, **counts}
        if coverage and process.returncode == 0:
            if smoke:
                smoke_command = [sys.executable, '-m', 'coverage', 'run', '--append', '--branch',
                                 '--source=model,game', 'game.py', '--smoke-test', '--screenshot', str(out / 'game.png')]
                result = subprocess.run(smoke_command, cwd=work, env=env, text=True, capture_output=True, timeout=40)
                (out / 'smoke.log').write_text(result.stdout + result.stderr)
                record['smoke_exit_code'] = result.returncode
                if result.returncode:
                    raise RuntimeError('Smoke test failed: ' + result.stdout + result.stderr)
            for args in (['json', '--pretty-print', '-o', str(out / 'coverage.json')],
                         ['html', '-d', str(out / 'htmlcov')], ['report', '-m']):
                result = subprocess.run([sys.executable, '-m', 'coverage', *args], cwd=work, env=env,
                                        text=True, capture_output=True, check=True)
                if args[0] == 'report':
                    (out / 'coverage.log').write_text(result.stdout)
            shutil.copy2(work / '.coverage', out / '.coverage')
        (out / 'outcome.json').write_text(json.dumps(record, indent=2))
        print(f'{label}: {record}', flush=True)
        return record


def main():
    RESULTS.mkdir(exist_ok=True)
    summary = {'utc_started': datetime.now(timezone.utc).isoformat(), 'python': sys.version,
               'tools': {name: version(name) for name in ('pytest','coverage','pygame-ce')},
               'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT / 'src').glob('*.py')},
               'mutations': [], 'bugs': []}
    summary['baseline'] = run_suite('baseline', 'baseline', coverage=True)
    if summary['baseline']['status'] != 'passed':
        raise RuntimeError('Baseline tests must pass before injecting any mutations')
    for bug in BUGS:
        before = run_suite(bug.id + '-open', 'baseline', mutation=bug)
        after = run_suite(bug.id + '-fixed', 'baseline')
        if before['status'] != 'killed' or after['status'] != 'passed':
            raise RuntimeError('Controlled defect was not detected and repaired')
        summary['bugs'].append({'definition': asdict(bug), 'before': before, 'after': after})
    for mutation in MUTATIONS:
        result = run_suite('baseline-' + mutation.id, 'baseline', mutation=mutation)
        summary['mutations'].append({'definition': asdict(mutation), 'before': result})
    summary['improved'] = run_suite('improved', 'improved', coverage=True)
    if summary['improved']['status'] != 'passed':
        raise RuntimeError('Improved tests must pass on original source')
    for entry, mutation in zip(summary['mutations'], MUTATIONS):
        entry['after'] = run_suite('improved-' + mutation.id, 'improved', mutation=mutation)
    summary['integration'] = run_suite('integration', 'improved', coverage=True, smoke=True)
    summary['utc_finished'] = datetime.now(timezone.utc).isoformat()
    (RESULTS / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    for key in ('before', 'after'):
        tally = {}
        for entry in summary['mutations']:
            status = entry[key]['status']
            tally[status] = tally.get(status, 0) + 1
        print(key, tally)
    if any(entry[when]['status'] in ('error', 'timeout') for entry in summary['mutations'] for when in ('before', 'after')):
        raise SystemExit('A mutation run did not complete normally; inspect results.')


if __name__ == '__main__':
    main()
