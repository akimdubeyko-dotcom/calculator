"""Reproduce the coursework experiments without modifying the playable game.

All variants live in fresh temporary directories. A killed mutant must cause an
actual test failure: collection errors, empty suites and timeouts are separate.
The 12 Y rules below define a bounded educational sample, not all possible mutants.
"""
import ast
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


@dataclass(frozen=True)
class Mutation:
    id: str
    module: str
    method: str
    operator: str
    before: str
    after: str
    description: str


MUTATIONS = [
    Mutation('Y01', 'model.py', 'GameState.update', 'AOR', 'self.time += dt', 'self.time = dt', 'Часы раунда заменяют накопление последним кадром'),
    Mutation('Y02', 'model.py', 'GameState.update', 'AOR', 'projectile.age += dt', 'projectile.age += dt * 2', 'Снаряд летит вдвое быстрее'),
    Mutation('Y03', 'model.py', 'GameState.update', 'ROR', 'if projectile.progress < 1:', 'if projectile.progress <= 1:', 'Попадание не происходит на границе полёта'),
    Mutation('Y04', 'model.py', 'GameState.update', 'CRP', 'self.hits += 1', 'self.hits += 2', 'Одно попадание засчитывается дважды'),
    Mutation('Y05', 'model.py', 'GameState.update', 'CALL', 'pending.append(projectile)', 'pending.insert(0, projectile)', 'Меняется порядок ещё летящих предметов'),
    Mutation('Y06', 'model.py', 'GameState.update', 'CRP', 'self.reaction = 0.65', 'self.reaction = 0.60', 'Реакция персонажа короче заданной'),
    Mutation('Y07', 'model.py', 'GameState.update', 'CRP', 'self.reply_time = 1.8', 'self.reply_time = 1.2', 'Ответная реплика исчезает раньше'),
    Mutation('Y08', 'model.py', 'GameState.throw', 'CRP', 'self.poses[self.speaker] = 0.5', 'self.poses[self.speaker] = 0.25', 'Поза броска исчезает раньше'),
    Mutation('Y09', 'model.py', 'GameState.throw', 'CRP', 'self.bubble_time = 2.4', 'self.bubble_time = 2.0', 'Реплика бросающего исчезает раньше'),
    Mutation('Y10', 'model.py', 'GameState.update', 'CRP', 'for _ in range(15):', 'for _ in range(14):', 'Создаётся на одну частицу меньше'),
    Mutation('Y11', 'model.py', 'GameState.update', 'AOR', 'particle.x += particle.vx * dt', 'particle.x -= particle.vx * dt', 'Частица движется против горизонтальной скорости'),
    Mutation('Y12', 'model.py', 'GameState.update', 'AOR', 'particle.y += particle.vy * dt', 'particle.y -= particle.vy * dt', 'Частица движется против вертикальной скорости'),
]
BUGS = [Mutation('BUG-MODEL-04', 'model.py', 'GameState.update', 'AOR',
    'projectile.age += dt', 'projectile.age = dt',
    'Возраст снаряда равен одному кадру вместо суммы: полёт не завершается')]


def modified(source, mutation):
    if source.count(mutation.before) != 1:
        raise ValueError(f'{mutation.id}: expected exactly one matching source fragment')
    result = source.replace(mutation.before, mutation.after, 1)
    ast.parse(result)
    return result


def junit_counts(path):
    if not path.exists():
        return {'tests': 0, 'failures': 0, 'errors': 1, 'skipped': 0}
    node = ET.parse(path).getroot()
    suites = [node] if node.tag == 'testsuite' else list(node.iter('testsuite'))
    # pytest 9 adds unittest subtest reports to the suite's `tests` attribute,
    # but keeps one testcase element per collected test. Preserve both counts.
    return {'tests': len(list(node.iter('testcase'))),
            'junit_reported_tests': sum(int(s.get('tests', 0)) for s in suites),
            **{key: sum(int(s.get(key, 0)) for s in suites) for key in ('failures', 'errors', 'skipped')}}


def run_suite(label, suite, mutation=None, coverage=False, smoke=False):
    out = RESULTS / label
    out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='derby-pr2-') as name:
        work = Path(name)
        for module in ('model.py', 'game.py'):
            source = (ROOT / 'src' / module).read_text()
            if mutation and mutation.module == module:
                source = modified(source, mutation)
                (out / module).write_text(source)
                (out / 'mutation.json').write_text(json.dumps(asdict(mutation), ensure_ascii=False, indent=2))
            (work / module).write_text(source)
        shutil.copytree(ROOT / 'tests' / suite, work / 'tests')
        shutil.copy2(ROOT / 'integration_probe.py', work / 'integration_probe.py')
        env = dict(os.environ)
        env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONDONTWRITEBYTECODE='1',
                   PYGAME_HIDE_SUPPORT_PROMPT='1', SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy')
        command = [sys.executable, '-m']
        if coverage:
            command += ['coverage', 'run', '--branch', '--source=model,game', '-m']
        command += ['pytest', '-q', '--tb=short', '--junitxml=' + str(out / 'junit.xml')]
        try:
            process = subprocess.run(command, cwd=work, env=env, text=True, capture_output=True, timeout=40)
        except subprocess.TimeoutExpired as error:
            (out / 'pytest.log').write_text(str(error))
            return {'status': 'timeout', 'exit_code': None, 'tests': 0}
        (out / 'pytest.log').write_text(process.stdout + process.stderr)
        counts = junit_counts(out / 'junit.xml')
        if process.returncode == 0 and counts['tests'] > 0 and not counts['errors'] and not counts['failures']:
            status = 'survived' if mutation else 'passed'
        elif process.returncode == 1 and counts['failures'] > 0 and counts['errors'] == 0:
            status = 'killed' if mutation else 'failed'
        else:
            status = 'error'
        record = {'status': status, 'exit_code': process.returncode, **counts}
        if coverage and process.returncode == 0:
            if smoke:
                smoke_command = [sys.executable, '-m', 'coverage', 'run', '--append', '--branch',
                                 '--source=model,game', 'game.py', '--smoke-test', '--screenshot', str(out / 'game.png')]
                result = subprocess.run(smoke_command, cwd=work, env=env, text=True, capture_output=True, timeout=40)
                (out / 'smoke.log').write_text(result.stdout + result.stderr)
                record['smoke_exit_code'] = result.returncode
                if result.returncode:
                    raise RuntimeError('Smoke test failed: ' + result.stdout + result.stderr)
            if smoke:
                probe_command = [sys.executable, '-m', 'coverage', 'run', '--append', '--branch',
                                 '--source=model,game', 'integration_probe.py', str(out / 'menu.png')]
                probe = subprocess.run(probe_command, cwd=work, env=env, text=True, capture_output=True, timeout=40)
                (out / 'menu-smoke.log').write_text(probe.stdout + probe.stderr)
                record['menu_smoke_exit_code'] = probe.returncode
                if probe.returncode:
                    raise RuntimeError('Menu integration failed: ' + probe.stdout + probe.stderr)
            for args in (['json', '--pretty-print', '-o', str(out / 'coverage.json')],
                         ['html', '-d', str(out / 'htmlcov')], ['report', '-m']):
                result = subprocess.run([sys.executable, '-m', 'coverage', *args], cwd=work, env=env,
                                        text=True, capture_output=True, check=True)
                if args[0] == 'report':
                    (out / 'coverage.log').write_text(result.stdout)
            shutil.copy2(work / '.coverage', out / '.coverage')
        (out / 'outcome.json').write_text(json.dumps(record, indent=2))
        print(f'{label}: {record}', flush=True)
        return record


def main():
    RESULTS.mkdir(exist_ok=True)
    summary = {'utc_started': datetime.now(timezone.utc).isoformat(), 'python': sys.version,
               'tools': {name: version(name) for name in ('pytest','coverage','pygame-ce')},
               'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT / 'src').glob('*.py')},
               'mutations': [], 'bugs': []}
    summary['baseline'] = run_suite('baseline', 'baseline', coverage=True)
    if summary['baseline']['status'] != 'passed':
        raise RuntimeError('Baseline tests must pass before injecting any mutations')
    for bug in BUGS:
        before = run_suite(bug.id + '-open', 'baseline', mutation=bug)
        after = run_suite(bug.id + '-fixed', 'baseline')
        if before['status'] != 'killed' or after['status'] != 'passed':
            raise RuntimeError('Controlled defect was not detected and repaired')
        summary['bugs'].append({'definition': asdict(bug), 'before': before, 'after': after})
    for mutation in MUTATIONS:
        result = run_suite('baseline-' + mutation.id, 'baseline', mutation=mutation)
        summary['mutations'].append({'definition': asdict(mutation), 'before': result})
    summary['improved'] = run_suite('improved', 'improved', coverage=True)
    if summary['improved']['status'] != 'passed':
        raise RuntimeError('Improved tests must pass on original source')
    for entry, mutation in zip(summary['mutations'], MUTATIONS):
        entry['after'] = run_suite('improved-' + mutation.id, 'improved', mutation=mutation)
    summary['integration'] = run_suite('integration', 'improved', coverage=True, smoke=True)
    summary['utc_finished'] = datetime.now(timezone.utc).isoformat()
    (RESULTS / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    for key in ('before', 'after'):
        tally = {}
        for entry in summary['mutations']:
            status = entry[key]['status']
            tally[status] = tally.get(status, 0) + 1
        print(key, tally)
    if any(entry[when]['status'] in ('error', 'timeout') for entry in summary['mutations'] for when in ('before', 'after')):
        raise SystemExit('A mutation run did not complete normally; inspect results.')


if __name__ == '__main__':
    main()
