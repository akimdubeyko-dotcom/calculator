"""Stronger oracles for pending order and visible animation lifetimes."""
import pytest
from model import GameState, Projectile, Particle, CLUBS, FANS


def test_unfinished_projectiles_keep_creation_order():
    state = GameState(seed=41)
    first = Projectile((10, 200), (300, 400), 0)
    second = Projectile((30, 200), (300, 400), 1)
    third = Projectile((50, 200), (300, 400), 2)
    state.projectiles = [first, second, third]
    state.update(0.125)
    assert state.projectiles == [first, second, third]
    assert [p.age for p in state.projectiles] == [0.125] * 3


def test_reaction_and_reply_use_their_own_lifetimes():
    state = GameState(seed=41)
    state.throw()
    state.update(0.8)
    assert state.reaction == pytest.approx(0.65)
    assert state.reply_time == pytest.approx(1.8)
    state.update(0.625)
    assert state.reaction == pytest.approx(0.025)
    assert state.reply_time == pytest.approx(1.175)
    state.update(2)
    assert state.reaction == 0 and state.reply_time == 0


def test_throw_pose_and_bubble_have_independent_timers():
    state = GameState(seed=41)
    state.throw()
    assert state.poses[0] == pytest.approx(0.5)
    assert state.bubble_time == pytest.approx(2.4)
    state.update(0.25)
    assert state.poses[0] == pytest.approx(0.25)
    assert state.bubble_time == pytest.approx(2.15)
    state.update(3)
    assert state.poses == [0] * len(FANS)
    assert state.bubble_time == 0


@pytest.mark.parametrize('count', [1, 2, 3])
def test_simultaneous_impacts_create_fifteen_particles_each(count):
    state = GameState(seed=41)
    state.projectiles = [Projectile((0, 0), (200, 300), i) for i in range(count)]
    assert state.update(0.8) == count
    assert state.hits == count
    assert len(state.particles) == 15 * count
    assert state.last_kind == count - 1


@pytest.mark.parametrize('vx,vy', [(80, -120), (-80, 120), (0, 0)])
def test_particle_moves_in_velocity_direction_before_gravity(vx, vy):
    state = GameState(seed=41)
    state.particles = [Particle(200, 300, vx, vy, 2, (1, 2, 3))]
    state.update(0.25)
    particle = state.particles[0]
    assert (particle.x, particle.y) == pytest.approx((200 + vx / 4, 300 + vy / 4))
    assert particle.vy == pytest.approx(vy + 115)
    assert particle.life == pytest.approx(1.75)


def test_midpoint_has_specified_arc_height():
    projectile = Projectile((120, 430), (620, 530), 0, age=0.4)
    assert projectile.position == pytest.approx((370, 335))


@pytest.mark.parametrize('invalid', [-1, 3, 99])
def test_invalid_item_keeps_previous_selection(invalid):
    state = GameState(seed=41)
    state.select(2)
    state.select(invalid)
    assert state.selected == 2


@pytest.mark.parametrize('role,index', [('unknown', 0), ('target', -1), ('throwers', len(CLUBS)), ('target', 1)])
def test_invalid_or_unchanged_club_preserves_round(role, index):
    state = GameState(seed=41)
    state.throw()
    assert not state.choose_club(role, index)
    assert (state.throwers, state.target, state.throws) == (0, 1, 1)
    assert len(state.projectiles) == 1


@pytest.mark.parametrize('role', ['throwers', 'target'])
def test_select_opponent_swaps_sides_and_clears_active_round(role):
    state = GameState(seed=41)
    state.throw()
    opponent = state.target if role == 'throwers' else state.throwers
    assert state.choose_club(role, opponent)
    assert (state.throwers, state.target) == (1, 0)
    assert state.throws == 0 and not state.projectiles


def test_zero_time_preserves_particle_until_exact_expiry():
    state = GameState(seed=41)
    particle = Particle(10, 20, 30, 40, 0.25, (0, 0, 0))
    state.particles = [particle]
    assert state.update(0) == 0
    assert (particle.x, particle.y, particle.life) == (10, 20, 0.25)
    state.update(0.25)
    assert state.particles == []
