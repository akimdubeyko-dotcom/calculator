"""Independent contract checks: frame-based projectile lifecycle."""
import math
import pytest
from model import GameState, Projectile, Particle, FANS, CLUBS, TARGET


def test_clock_accumulates_unequal_frames():
    state = GameState(seed=41)
    for dt in (0.125, 0.25, 0.125):
        state.update(dt)
    assert state.time == pytest.approx(0.5)


def test_flight_finishes_after_four_short_frames():
    state = GameState(seed=41)
    assert state.throw()
    assert state.update(0.2) == 0
    assert state.update(0.2) == 0
    assert state.update(0.2) == 0
    assert state.hits == 0
    assert state.update(0.2) == 1
    assert state.hits == 1
    assert state.projectiles == []
    assert state.particles
    assert state.update(0) == 0
    assert state.hits == 1


@pytest.mark.parametrize('age, expected', [(-1, 0), (0, 0), (0.4, 0.5), (0.8, 1), (2, 1)])
def test_progress_bounds(age, expected):
    assert Projectile((0, 0), (100, 100), 0, age=age).progress == expected


@pytest.mark.parametrize('age, expected', [(0, (120, 430)), (0.8, (620, 530))])
def test_trajectory_endpoints(age, expected):
    assert Projectile((120, 430), (620, 530), 0, age=age).position == expected


def test_repeated_press_waits_for_cooldown():
    state = GameState(seed=41)
    assert state.throw()
    assert not state.throw()
    state.update(0.125)
    assert not state.throw()
    state.update(0.125)
    assert state.throw()
    assert state.throws == 2


@pytest.mark.parametrize('kind', [0, 1, 2])
def test_selected_item_reaches_target(kind):
    state = GameState(seed=41)
    state.select(kind)
    assert state.throw()
    projectile = state.projectiles[0]
    assert projectile.kind == kind
    assert abs(projectile.end[0] - TARGET[0]) <= 15
    assert abs(projectile.end[1] - TARGET[1]) <= 10
    assert state.update(0.8) == 1
    assert state.last_kind == kind


def test_reset_clears_round_preserving_teams():
    state = GameState(seed=41)
    state.choose_club('throwers', 3)
    state.choose_club('target', 4)
    state.throw()
    state.update(0.8)
    state.reset()
    assert (state.throwers, state.target) == (3, 4)
    assert (state.throws, state.hits, state.time) == (0, 0, 0)
    assert not state.projectiles and not state.particles
    assert not state.bubble and not state.reply


@pytest.mark.parametrize('dt', [-0.1, math.inf, -math.inf, math.nan])
def test_invalid_frame_does_not_change_clock(dt):
    state = GameState(seed=41)
    with pytest.raises(ValueError):
        state.update(dt)
    assert state.time == 0


def test_finished_particles_are_cleaned_up():
    state = GameState(seed=41)
    state.throw()
    state.update(0.8)
    assert state.particles
    state.update(1.0)
    assert not state.particles


def test_speaker_cycles_all_positions():
    state = GameState(seed=41)
    speakers = []
    for _ in range(len(FANS) + 1):
        assert state.throw()
        speakers.append(state.speaker)
        state.update(0.25)
    assert speakers == list(range(len(FANS))) + [0]
