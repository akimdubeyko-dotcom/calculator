"""Initial specification tests for the menu and the event controller."""
import os
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')
import pygame
import pytest
from unittest.mock import Mock
from game import Game, Text, WIDTH, HEIGHT, CLUBS
from model import GameState


@pytest.fixture
def game():
    pygame.display.init()
    pygame.font.init()
    pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.event.clear()
    g = Game.__new__(Game)
    g.window = pygame.Surface((WIDTH, HEIGHT))
    g.canvas = pygame.Surface((WIDTH, HEIGHT))
    g.text = Text()
    g.text.draw = Mock(wraps=g.text.draw)
    g.state = GameState(seed=51)
    g.sound = Mock()
    g.running = True
    g.team_menu = False
    g.draw = Mock()
    yield g
    pygame.quit()


def key(game, value):
    game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=value))


def test_initial_scene_is_ready(game):
    assert game.running and not game.team_menu
    assert (game.state.throwers, game.state.target) == (0, 1)


def test_t_opens_team_menu(game):
    key(game, pygame.K_t)
    assert game.team_menu and game.running


def test_t_closes_team_menu(game):
    game.team_menu = True
    key(game, pygame.K_t)
    assert not game.team_menu and game.running


def test_enter_closes_menu_without_exit(game):
    game.team_menu = True
    key(game, pygame.K_RETURN)
    assert not game.team_menu and game.running


def test_escape_closes_menu_without_exit(game):
    game.team_menu = True
    key(game, pygame.K_ESCAPE)
    assert not game.team_menu and game.running


def test_window_quit_works_even_in_menu(game):
    game.team_menu = True
    game.handle_event(pygame.event.Event(pygame.QUIT))
    assert not game.running


def test_accepted_throw_has_one_sound(game):
    game.throw()
    assert game.state.throws == 1
    game.sound.play.assert_called_once_with('throw')


def test_space_starts_throw_in_game(game):
    key(game, pygame.K_SPACE)
    assert game.state.throws == 1


def test_digit_selects_third_item_in_game(game):
    key(game, pygame.K_3)
    assert game.state.selected == 2


def test_native_viewport_has_no_padding(game):
    assert game.viewport() == ((1200, 800), (0, 0))


def test_native_mouse_preserves_coordinates(game):
    assert game.logical_mouse((600, 400)) == (600, 400)


def test_menu_pauses_simulation_but_redraws(game):
    game.team_menu = True
    game.step(.2)
    assert game.state.time == 0
    game.draw.assert_called_once_with()
    game.sound.play.assert_not_called()


def test_enter_resumes_update_in_same_frame(game):
    game.team_menu = True
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))
    game.step(.2)
    assert not game.team_menu and game.running
    assert game.state.time == pytest.approx(.2)
    game.draw.assert_called_once_with()


def test_menu_displays_twenty_club_rows_and_two_selected(game):
    game.draw_team_menu()
    names = {club.name for club in CLUBS}
    rows = [c.args for c in game.text.draw.call_args_list if c.args[1] in names]
    assert len(rows) == 20
    assert sum(bool(row[5]) for row in rows) == 2
    assert {row[1] for row in rows if row[5]} == {CLUBS[0].name, CLUBS[1].name}
