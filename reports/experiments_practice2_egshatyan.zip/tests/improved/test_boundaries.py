"""Additional behavior and boundary assertions motivated by surviving mutants."""
import pygame
import pytest
from game import TEAM_DONE, TEAM_CHOICES, TEAM_BUTTON, WIDTH, HEIGHT, CLUBS
from test_interaction import game, key


def click(game, position, button=1):
    game.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=button, pos=position))


@pytest.mark.parametrize('value', [pygame.K_SPACE, pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_r, pygame.K_m])
def test_gameplay_keys_are_ignored_in_menu(game, value):
    game.state.throw()
    game.state.select(1)
    game.state.update(.3)
    before = (game.state.throws, game.state.selected, len(game.state.projectiles))
    game.team_menu = True
    key(game, value)
    assert (game.state.throws, game.state.selected, len(game.state.projectiles)) == before
    assert game.team_menu and game.running
    game.sound.play.assert_not_called()
    game.sound.toggle.assert_not_called()


@pytest.mark.parametrize('button', [2, 3])
@pytest.mark.parametrize('position', [TEAM_DONE.center, TEAM_CHOICES[4][2].center])
def test_non_left_mouse_button_is_ignored(game, button, position):
    game.team_menu = True
    before = (game.state.throwers, game.state.target)
    click(game, position, button)
    assert game.team_menu
    assert (game.state.throwers, game.state.target) == before


def test_done_button_closes_menu_without_exit(game):
    game.team_menu = True
    click(game, TEAM_DONE.center)
    assert not game.team_menu and game.running


def test_left_column_changes_throwers_only(game):
    game.team_menu = True
    click(game, TEAM_CHOICES[4][2].center)
    assert (game.state.throwers, game.state.target) == (4, 1)
    assert game.team_menu


@pytest.mark.parametrize('window,size,offset', [
    ((1600,800),(1200,800),(200,0)),
    ((1200,1000),(1200,800),(0,100)),
    ((900,900),(900,600),(0,150)),
    ((480,320),(480,320),(0,0)),
])
def test_viewport_preserves_aspect_ratio_and_centers(game, window, size, offset):
    game.window = pygame.Surface(window)
    assert game.viewport() == (size, offset)


@pytest.mark.parametrize('window,size,offset', [
    ((1600,800),(1200,800),(200,0)),
    ((900,900),(900,600),(0,150)),
])
@pytest.mark.parametrize('logical', [(0,0),(1200,0),(0,800),(1200,800),(600,400)])
def test_mouse_maps_known_screen_points(game, window, size, offset, logical):
    game.window = pygame.Surface(window)
    # Screen coordinates are computed from an explicit expected viewport,
    # independently of Game.viewport() and Game.logical_mouse().
    screen = (offset[0]+logical[0]*size[0]/WIDTH, offset[1]+logical[1]*size[1]/HEIGHT)
    assert game.logical_mouse(screen) == pytest.approx(logical)


def test_padding_click_does_not_select_club(game):
    game.window = pygame.Surface((1200,1000))
    game.team_menu = True
    click(game, (650, 20))
    assert game.logical_mouse((650,20)) == (650,-80)
    assert (game.state.throwers,game.state.target) == (0,1)


def test_resized_left_column_click_selects_correct_club(game):
    game.window = pygame.Surface((900,900))
    game.team_menu = True
    x,y = TEAM_CHOICES[6][2].center
    click(game, (x*.75,150+y*.75))
    assert (game.state.throwers,game.state.target) == (6,1)


def test_rejected_throw_is_silent(game):
    game.state.throw()
    game.throw()
    assert game.state.throws == 1
    game.sound.play.assert_not_called()


@pytest.mark.parametrize('position,closed', [
    ((450,697),True), ((749,744),True),
    ((750,720),False), ((600,745),False),
])
def test_done_button_uses_half_open_pixel_bounds(game, position, closed):
    game.team_menu = True
    click(game, position)
    assert game.team_menu is (not closed)
    assert game.running


def test_selection_highlights_follow_changed_teams(game):
    game.state.choose_club('throwers',3)
    game.state.choose_club('target',7)
    game.draw_team_menu()
    names = {c.name for c in CLUBS}
    selected = [c.args[1] for c in game.text.draw.call_args_list
                if c.args[1] in names and c.args[5]]
    assert selected == [CLUBS[3].name,CLUBS[7].name]


def test_flight_is_frozen_and_resumes_after_menu(game):
    game.state.throw()
    game.state.update(.1)
    p = game.state.projectiles[0]
    before = (p.age,p.position,game.state.cooldown,game.state.time)
    game.team_menu = True
    game.step(.4)
    assert (p.age,p.position,game.state.cooldown,game.state.time) == before
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_RETURN))
    game.step(.2)
    assert p.age == pytest.approx(.3)
    assert game.state.time == pytest.approx(.3)
    assert game.state.cooldown == 0


def test_team_button_opens_menu_and_escape_in_game_exits(game):
    click(game, TEAM_BUTTON.center)
    assert game.team_menu
    key(game,pygame.K_ESCAPE)
    assert game.running and not game.team_menu
    key(game,pygame.K_ESCAPE)
    assert not game.running
