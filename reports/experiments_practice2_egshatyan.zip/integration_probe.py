"""Real Pygame menu integration, deterministic and independent of unit stubs."""
import sys
import pygame
from game import Game, TEAM_CHOICES, TEAM_DONE

g = Game(seed=51)
try:
    g.throw()
    g.step(.1)
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_t))
    g.step(.4)
    assert g.team_menu and g.state.time == .1
    pygame.image.save(g.canvas,sys.argv[1])
    for role,index,rect in (TEAM_CHOICES[4],TEAM_CHOICES[17]):
        pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=rect.center))
        g.step(.1)
        assert getattr(g.state,role) == index
        assert g.state.time == 0
    pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=TEAM_DONE.center))
    g.step(.1)
    assert not g.team_menu and g.running and g.state.time == .1
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_t))
    g.step(.1)
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_ESCAPE))
    g.step(.1)
    assert not g.team_menu and g.running
    pygame.event.post(pygame.event.Event(pygame.QUIT))
    g.step(.1)
    assert not g.running
    print('Menu integration passed: rendering, pause, both columns, Done, Escape, resume, Quit.')
finally:
    pygame.quit()
