"""Exercise the real dummy mixer and keyboard; this does not assess loudspeakers."""
from pathlib import Path
import sys
import pygame
from game import Game

game = Game(seed=61)
assert game.sound.available
assert game.sound.enabled
game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_m))
assert not game.sound.enabled
game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_SPACE))
assert game.state.throws == 1
game.step(.8)
assert game.state.hits == 1
game.draw()
pygame.image.save(game.canvas, sys.argv[1])
game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_t))
game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_m))
assert not game.sound.enabled
game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_t))
game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_m))
assert game.sound.enabled
game.sound.play('throw')
game.sound.play('hit')
pygame.quit()
print('Sound integration: mute, throw, hit, menu guard, unmute — PASS')
