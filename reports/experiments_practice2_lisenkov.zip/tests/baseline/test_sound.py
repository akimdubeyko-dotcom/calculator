"""Independent sound contracts; mixer devices are replaced with controlled mocks."""
from types import SimpleNamespace
from unittest.mock import Mock
import pygame
import pytest
from game import Sound, Game


def test_initialization_enables_two_effects(sound):
    assert sound.enabled is True
    assert sound.available is True
    assert set(sound.sounds) == {'throw', 'hit'}


def test_mixer_failure_disables_audio(monkeypatch):
    monkeypatch.setattr(pygame.mixer, 'init', Mock(side_effect=pygame.error('no device')))
    sound = Sound()
    assert sound.available is False
    assert sound.enabled is False
    assert sound.sounds == {}


def test_toggle_available_sound(sound):
    sound.toggle()
    assert sound.enabled is False


def test_toggle_unavailable_does_not_enable_audio():
    sound = Sound.__new__(Sound)
    sound.available = False
    sound.enabled = False
    sound.sounds = {}
    sound.toggle()
    assert sound.enabled is False


def test_play_throw_when_enabled(sound):
    sound.play('throw')
    sound.sounds['throw'].play.assert_called_once_with()


def test_play_fully_disabled_is_silent(sound):
    sound.available = sound.enabled = False
    sound.play('throw')
    sound.sounds['throw'].play.assert_not_called()


def test_key_m_dispatches_toggle(controller):
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_m))
    controller.sound.toggle.assert_called_once_with()


def test_successful_throw_sound(controller):
    controller.state.throw.return_value = True
    controller.throw()
    controller.sound.play.assert_called_once_with('throw')


def test_hit_dispatch(controller, monkeypatch):
    monkeypatch.setattr(pygame.event, 'get', lambda: [])
    controller.state.update.return_value = 1
    controller.step(0.1)
    controller.sound.play.assert_called_once_with('hit')
    controller.draw.assert_called_once_with()


def test_zero_hits_is_silent(controller, monkeypatch):
    monkeypatch.setattr(pygame.event, 'get', lambda: [])
    controller.state.update.return_value = 0
    controller.step(0.1)
    controller.sound.play.assert_not_called()
