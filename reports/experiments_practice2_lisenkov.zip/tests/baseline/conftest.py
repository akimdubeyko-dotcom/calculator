from unittest.mock import Mock
import pytest
import pygame
from game import Sound, Game

@pytest.fixture
def mixer(monkeypatch):
    init = Mock()
    factory = Mock(side_effect=lambda **kwargs: Mock())
    monkeypatch.setattr(pygame.mixer, 'init', init)
    monkeypatch.setattr(pygame.mixer, 'Sound', factory)
    return init, factory


@pytest.fixture
def sound(mixer):
    return Sound()


@pytest.fixture
def controller():
    game = Game.__new__(Game)
    game.sound = Mock()
    game.state = Mock()
    game.running = True
    game.team_menu = False
    game.draw = Mock()
    return game


