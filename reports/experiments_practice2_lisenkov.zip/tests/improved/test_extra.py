"""Boundary, routing, and PCM synthesis assertions added after survivors."""
import math
from unittest.mock import Mock, call
import pygame
import pytest
from game import Sound


def test_mixer_format_matches_pcm(sound, mixer):
    mixer[0].assert_called_once_with(frequency=22050, size=-16, channels=1, buffer=512)


@pytest.mark.parametrize('index,duration', [(0, 0.12), (1, 0.18)])
def test_pcm_count(sound, mixer, index, duration):
    samples = mixer[1].call_args_list[index].kwargs['buffer']
    assert samples.typecode == 'h'
    assert len(samples) == int(22050*duration)


@pytest.mark.parametrize('index', [0,1])
def test_pcm_amplitude_and_envelope(sound, mixer, index):
    samples = mixer[1].call_args_list[index].kwargs['buffer']
    # Regression contract: audible signed PCM, soft attack, fading final segment.
    peak = max(map(abs, samples))
    assert 4000 < peak < 6500
    assert max(samples) > 0 and min(samples) < 0
    assert samples[0] == 0
    assert max(map(abs, samples[:len(samples)//100])) < 2000
    assert max(map(abs, samples[-len(samples)//10:])) < 100


def test_effects_have_distinct_pcm(sound, mixer):
    a, b = [call.kwargs['buffer'] for call in mixer[1].call_args_list]
    assert list(a[:200]) != list(b[:200])


@pytest.mark.parametrize('name', ['throw','hit'])
@pytest.mark.parametrize('enabled,available', [(True,True),(True,False),(False,True),(False,False)])
def test_play_truth_table(sound, name, enabled, available):
    sound.enabled, sound.available = enabled, available
    sound.play(name)
    for key, effect in sound.sounds.items():
        assert effect.play.call_count == int(enabled and available and key == name)


@pytest.mark.parametrize('initial', [True, False])
def test_toggle_roundtrip(sound, initial):
    sound.enabled = initial
    sound.toggle()
    assert sound.enabled is not initial
    sound.toggle()
    assert sound.enabled is initial


@pytest.mark.parametrize('initial', [True,False])
def test_unavailable_toggle_preserves_state(sound, initial):
    sound.enabled, sound.available = initial, False
    sound.toggle()
    assert sound.enabled is initial


def test_sound_creation_failure_is_safe(monkeypatch):
    monkeypatch.setattr(pygame.mixer, 'init', Mock())
    monkeypatch.setattr(pygame.mixer, 'Sound', Mock(side_effect=pygame.error('bad PCM')))
    sound = Sound()
    assert sound.enabled is False and sound.available is False
    sound.play('hit')


def test_rejected_throw_has_no_sound(controller):
    controller.state.throw.return_value = False
    controller.throw()
    controller.sound.play.assert_not_called()


@pytest.mark.parametrize('hits', [0, 1, 3])
def test_step_sound_once_per_update(controller, monkeypatch, hits):
    monkeypatch.setattr(pygame.event, 'get', lambda: [])
    controller.state.update.return_value = hits
    controller.step(.2)
    controller.state.update.assert_called_once_with(.2)
    assert controller.sound.play.call_args_list == ([call('hit')] if hits else [])
    controller.draw.assert_called_once_with()


@pytest.mark.parametrize('key', [pygame.K_m, pygame.K_SPACE, pygame.K_r])
def test_menu_blocks_sound_commands(controller, key):
    controller.team_menu = True
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=key))
    assert controller.sound.mock_calls == []
    assert controller.state.mock_calls == []


def test_menu_step_does_not_update_or_play(controller, monkeypatch):
    monkeypatch.setattr(pygame.event, 'get', lambda: [])
    controller.team_menu = True
    controller.step(.5)
    controller.state.update.assert_not_called()
    controller.sound.play.assert_not_called()
    controller.draw.assert_called_once_with()


def test_reset_does_not_change_audio_preference(controller, sound):
    controller.sound = sound
    sound.enabled = False
    controller.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_r))
    controller.state.reset.assert_called_once_with()
    assert sound.enabled is False


def test_m_toggle_applies_before_hit_in_same_frame(controller, sound, monkeypatch):
    controller.sound = sound
    event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_m)
    monkeypatch.setattr(pygame.event, 'get', lambda: [event])
    controller.state.update.return_value = 1
    controller.step(.1)
    assert sound.enabled is False
    sound.sounds['hit'].play.assert_not_called()
